# jdbc
The util class for jdbc
# just write those codes for use again 
